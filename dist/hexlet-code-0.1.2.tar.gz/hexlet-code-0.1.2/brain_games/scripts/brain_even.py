#!/usr/bin/env python
from brain_games import brain_even


def main():
    brain_even.brain_even()


if __name__ == '__main__':
    main()
