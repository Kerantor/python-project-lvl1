import prompt


def welcome_user():
    print("Welcome to Brain Games!")
    prompt.string('May i have you name? ')
