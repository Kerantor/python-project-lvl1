import prompt


def welcome_user():
    prompt.string('May i have you name? ')
